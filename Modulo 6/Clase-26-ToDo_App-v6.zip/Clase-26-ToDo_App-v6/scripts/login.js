/* --------------- COMPROBACION, antes de la carga del DOM 👇 --------------- */

// evaluar si hay un token para mandarlo directo a sus tareas
const jwt = localStorage.getItem('jwt');

if (jwt) {
    // usamos el replace para no guardar en el historial la url anterior
    location.replace('/mis-tareas.html');
}
/* ------------------------------------ ☝ ----------------------------------- */


window.addEventListener('load', function () {
    /* ---------------------- obtenemos variables globales ---------------------- */
    const form = document.querySelector('form');
    const inputEmail = document.querySelector('#inputEmail');
    const inputPassword = document.querySelector('#inputPassword');
    const loader = this.document.querySelector('.loader');
    const ingresar = this.document.querySelector('#ingresar');
    const btnSubmit = this.document.querySelector('form button');





    /* -------------------------------------------------------------------------- */
    /*            FUNCIÓN 1: Escuchamos el submit y preparamos el envío           */
    /* -------------------------------------------------------------------------- */
    form.addEventListener('submit', function (event) {

        event.preventDefault();

        console.log("se hizo submit");

        // deshabilitamos el boton
        btnSubmit.setAttribute('disabled', '');
        // aparecer el loader
        loader.classList.remove('oculto');
        // esconder la palabra Ingresar
        ingresar.classList.add('oculto')


        const usuario = {
            email: inputEmail.value,
            password: inputPassword.value
        }

        // llamamos a a funcion para loggearnos
        realizarLogin(usuario)


    });


    /* -------------------------------------------------------------------------- */
    /*                     FUNCIÓN 2: Realizar el login [POST]                    */
    /* -------------------------------------------------------------------------- */
    // function realizarLogin(user) {
    //     const url = 'https://ctd-todo-api.herokuapp.com/v1/users/login';

    //     const configuraciones = {
    //         method: 'POST',
    //         headers: {
    //             'Content-Type': 'application/json'
    //         },
    //         body: JSON.stringify(user)
    //     }

    //     fetch(url, configuraciones)
    //         .then(respuesta => respuesta.json())
    //         .then(data => {
    //             console.log('RESPUESTA DEL SERVIDOR');
    //             console.log(data)


    //             // si es correcto el usuarios nos llega un token
    //             // entoces lo guardamos en el deposito para ir a la siguiente pantalla
    //             if (data.jwt) {
    //                 // guardamos ese token que nos llega
    //                 localStorage.setItem('jwt', data.jwt)

    //                 location.replace('/mis-tareas.html')
    //             }
    //         })
    //         .catch(err => {
    //             console.log("Promesa rechazada:");
    //             console.log(err);
    //         })





    // };

    /* -------------------------------------------------------------------------- */
    /*                     FUNCIÓN 2: Realizar el login [POST]                    */
    /* -------------------------------------------------------------------------- */

    // version Async Await
    async function realizarLogin(user) {
        const url = 'https://ctd-todo-api.herokuapp.com/v1/users/login';

        const configuraciones = {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(user)
        }

        const respuesta = await fetch(url, configuraciones)
        console.log(respuesta);

        const data = await respuesta.json();
        console.log(data);

        // si es correcto el usuarios nos llega un token
        // entoces lo guardamos en el deposito para ir a la siguiente pantalla
        if (data.jwt) {
            // guardamos ese token que nos llega
            localStorage.setItem('jwt', data.jwt)

            location.replace('/mis-tareas.html')
        } else {
            // habilitamos el boton
            btnSubmit.removeAttribute('disabled');
            // escondemo el loader
            loader.classList.add('oculto');
            // mostramos la palabra Ingresar
            ingresar.classList.remove('oculto')
            alert("Credenciales incorrectas.")
        }





    };

});